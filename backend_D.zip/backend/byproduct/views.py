from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import ByProduct
from .serializers import ByProductSerializer

@api_view(['GET'])
def list_byproducts(request):
    data = ByProduct.objects.all()
    serializer = ByProductSerializer(data, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def add_byproduct(request):
    serializer = ByProductSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "ByProduct added"})
    return Response(serializer.errors)
