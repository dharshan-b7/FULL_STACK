from django.urls import path
from . import views

urlpatterns = [
    path('list/', views.list_materials),
    path('add/', views.add_material),
]
