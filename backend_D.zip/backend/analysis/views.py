from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import MaterialAnalysis
from .serializers import MaterialAnalysisSerializer

@api_view(['GET'])
def list_materials(request):
    data = MaterialAnalysis.objects.all()
    serializer = MaterialAnalysisSerializer(data, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def add_material(request):
    serializer = MaterialAnalysisSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Material added"})
    return Response(serializer.errors)
